Henry Ho, A00990152, 1A, hho81@my.bcit.ca	

Victor Vuong, A01021299, 1A, vvuong3@my.bcit.ca

We completed everything that was required.

The major challenge was modifying the bootstrap to personalize our website.